import boto3, calendar, os, json
from boto3.dynamodb.conditions import Key
from datetime import datetime, date, timedelta
from ics import Calendar, Event
import pytz

# get list of Client time slots from cloudformation as a input
ClientAvailableDays = os.environ['ClientAvailableDays'].split(',')
ClientAppointmentTime = os.environ['ClientAppointmentTime'].split(',')
ClientExceptionDates = os.environ['ClientExceptionDates'].split(',')
SNSTopicArn = os.environ['SNSTopicArn']
BucketName = os.environ['BucketName']
tableName = os.environ['TableName']

now = datetime.now()
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(tableName)
    
def lambda_handler(event, context):
    # get name and appointmentDate from chatbot
    print('received request: ' + str(event))
    if event['currentIntent']['name'] == 'createAppointment':
        appointmentDate = event['currentIntent']['slots']['AppointmentDate']
        name = event['currentIntent']['slots']['Name']
        
        # check if date matching with Client available days and exception dates
        if (convertDateToDay(appointmentDate) in ClientAvailableDays and appointmentDate not in ClientExceptionDates): 
            print ("Element Exists in available days and not in exception dates")
            
            # check if record exist
            response = table.get_item(
                Key={ 
                    'Name': name,
                    'AppointmentDate': appointmentDate,
                }
            )
        
            # book an appointment
            if 'Item' not in response:
                #show the list of available time slots and send to chatbot
                AvailableTimeSlots = set(ClientAppointmentTime).difference(ShowAvailableTimeList(appointmentDate))
                print ('AvailableTimeSlots if' +str(AvailableTimeSlots))
                buttons = None
                if AvailableTimeSlots != set():
                    buttons = []
                    for timeSlot in AvailableTimeSlots:
                        buttons.append({ "text": timeSlot, "value": "confirm appointment for " + str(timeSlot)})
                    
                    response = {
                    "sessionAttributes": {
                      "AppointmentDate": appointmentDate,
                      "Name": name
                    },
                	"dialogAction": {
                		"type": "ElicitIntent",
                		"message": {
                		    "contentType": "PlainText",
                		    "content": "Following appointment time slots are available"
                		},
                		"responseCard": {
                			"version": 1.0,
                			"contentType": "application/vnd.amazonaws.card.generic",
                			"genericAttachments": [{
                				"title": "Choose appointment Time",
                				"buttons": buttons
                			}]
                		}
                	}
                }
                else:
                    response = {
                        "dialogAction": {
                        	"type": "ElicitSlot",
                        	"message": {
                        		"contentType": "PlainText",
                        		"content": "Sorry, all appointment slots are booked for the provided date. Please provide another date"
                        	},
                        	"intentName": "createAppointment",
                        	"slots": {
                        		"Name": name
                        	},
                        	"slotToElicit": "AppointmentDate",
                        }
                    }
                    
                print ("Type of Response: " + str(type(response)))
                return response
            # cancel a appointment
            else:
                item = response['Item']
                response = {
                    "sessionAttributes": {
                      "AppointmentDate": appointmentDate,
                      "Name": name,
                      "AppointmentTime": item['AppointmentTime']
                    },
                	"dialogAction": {
                		"type": "ConfirmIntent",
                		"message": {
                		    "contentType": "PlainText",
                		    "content": "You have already booked an appointment on this date. Do you want to cancel this appointment?"
                		},
                		"intentName": "cancelAppointment",
                		"slots": {
                		    "appointmentDate": appointmentDate,
                		    "Name": name
                	    }
                	}
                }
                return response
        else:
            print ("not exist in available days or present in exception dates")
            # send a message to chatbot that at this given date Client is not available, provide different date. 
            return {
                "dialogAction": {
                	"type": "ElicitSlot",
                	"message": {
                		"contentType": "PlainText",
                		"content": "Sorry, we are not available on the provided date. Please provide another date"
                	},
                	"intentName": "createAppointment",
                	"slots": {
                		"Name": name
                	},
                	"slotToElicit": "AppointmentDate",
                }
            }
    
    if event['currentIntent']['name'] == 'confirmTheAppointment':
        # get appointment time from chatbot and name, date from sesion attribute
        appointmentDate = event['sessionAttributes']['AppointmentDate']
        name = event['sessionAttributes']['Name']
        appointmentTime = event['currentIntent']['slotDetails']['appointmentTime']['originalValue']
        
        # send calendar event to email 
        calendar_ics(name,appointmentDate,appointmentTime, 'create')
        
        # save record
        table.put_item(
            Item={
                'Name': name,
                'AppointmentDate': appointmentDate,
                'AppointmentTime': appointmentTime,
                'CreationDateAndTime': str(now)
            }
        )
        return {
            "dialogAction": {
            	"type": "Close",
            	"fulfillmentState": "Fulfilled",
            	"message": {
            		"contentType": "PlainText",
            		"content": "Your appointment has been confirmed!"
            	}
            }
        }
    
    if event['currentIntent']['name'] == 'cancelAppointment':
        appointmentDate = event['currentIntent']['slots']['appointmentDate']
        name = event['currentIntent']['slots']['Name']
        status = event['currentIntent']['confirmationStatus']
        
        if status == 'Confirmed':
            appointmentTime = event['sessionAttributes']['AppointmentTime']
            calendar_ics(name, appointmentDate, appointmentTime, 'cancel')
            #delete the record
            response = table.delete_item(
                Key={
                    'Name': name,
                    'AppointmentDate': appointmentDate,
                }
            )
            return {
                "dialogAction": {
                	"type": "Close",
                	"fulfillmentState": "Fulfilled",
                	"message": {
                		"contentType": "PlainText",
                		"content": "Your appointment has been cancelled!"
                	}
                }
            }
        if status == 'Denied':
            return {
                "dialogAction": {
                	"type": "Close",
                	"fulfillmentState": "Fulfilled",
                	"message": {
                		"contentType": "PlainText",
                		"content": "Ok."
                	}
                }
            }
            
        if status == 'None':
            # check if record exist
            response = table.get_item(
                Key={ 
                    'Name': name,
                    'AppointmentDate': appointmentDate,
                }
            )
            if 'Item' in response:
                return {
                    "sessionAttributes": {
                      "AppointmentDate": appointmentDate,
                      "Name": name,
                      "AppointmentTime": response['Item']['AppointmentTime']
                    },
                	"dialogAction": {
                		"type": "ConfirmIntent",
                		"message": {
                		    "contentType": "PlainText",
                		    "content": "Do you want to cancel this appointment?"
                		},
                		"intentName": "cancelAppointment",
                		"slots": {
                		    "appointmentDate": appointmentDate,
                		    "Name": name
                	    }
                	}
                }
            else:
                return {
                    "dialogAction": {
                	    "type": "Close",
                	    "fulfillmentState": "Fulfilled",
                	    "message": {
                		    "contentType": "PlainText",
                		    "content": "Record doesnot exist."
                	    }
                    }
                }
                

# showing the list of bookings of that particular date
def ShowAvailableTimeList(appointmentDate):
    response = table.query(
        IndexName='project_index', 
        KeyConditionExpression=Key('AppointmentDate').eq(appointmentDate)
    )
    AppoinementTimeList = []
    for i in response['Items']:
        print(i['AppointmentDate'], ":", i['AppointmentTime'])   
        AppoinementTimeList.append(i['AppointmentTime'])
    return AppoinementTimeList
    
def convertDateToDay(appointmentDate):
    day = calendar.day_name[datetime.strptime(appointmentDate, '%Y-%m-%d').weekday()]
    print('here  in convertDateToDay   '+str(day))
    return day
    
def calendar_ics(name,appointmentDate,appointmentTime, event_type):
    c = Calendar()
    e = Event()
    
    if (event_type == 'create'):
        e.name = name+"'s Appointment"
    else:
        e.name = "Cancelled: " + name + "'s Appointment"      
    event_datetime = datetime.strptime(appointmentDate+' '+appointmentTime, '%Y-%m-%d %H:%M')
    e.begin = event_datetime
    e.duration = timedelta(minutes=30)
    c.events.add(e)
    print (c.events)
    file_name = name+"_"+appointmentDate+" "+appointmentTime+".ics"
    lambda_path= "/tmp/ "+ file_name
    with open(lambda_path, 'w') as my_file:
        my_file.writelines(c)
    bucket_name = BucketName
    s3 = boto3.resource("s3")
    s3.meta.client.upload_file(lambda_path, bucket_name, file_name)
    s3_client = boto3.client("s3")
    presigned_url = s3_client.generate_presigned_url(
        'get_object',
        Params = {'Bucket': bucket_name, 'Key': file_name}
    )
    sns = boto3.client('sns')
    # Publish a simple message to the specified SNS topic
    response = sns.publish(
        TopicArn=SNSTopicArn,    
        Message=presigned_url,    
    )
    print(response)